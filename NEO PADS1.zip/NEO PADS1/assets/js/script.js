/* ============================================================
   NEO PADS1 WEBSITE SCRIPT
   This file adds a bit of interactivity to the website.
   It waits until the whole page has loaded, then runs.
   ============================================================ */

document.addEventListener("DOMContentLoaded", function () {
  /* --------------------------------------------------------
     1. MOBILE NAVIGATION TOGGLE
     On small screens the menu is hidden. When someone clicks
     the hamburger button, we add/remove the "is-open" class,
     which the CSS uses to show or hide the menu.
     -------------------------------------------------------- */
  var navToggle = document.querySelector(".nav-toggle");
  var navMenu = document.querySelector(".nav-menu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", function () {
      // toggle() switches the class on and off each time we click
      navMenu.classList.toggle("is-open");

      // update aria-expanded so screen readers know if the menu is open
      var isOpen = navMenu.classList.contains("is-open");
      navToggle.setAttribute("aria-expanded", isOpen);
    });

    // close the mobile menu automatically once a link is clicked
    var navLinks = navMenu.querySelectorAll("a");
    navLinks.forEach(function (link) {
      link.addEventListener("click", function () {
        navMenu.classList.remove("is-open");
      });
    });
  }

  /* --------------------------------------------------------
     2. HIGHLIGHT THE CURRENT PAGE IN THE NAVIGATION MENU
     We compare the current page's file name to each link's
     "href" and add the "active" class when they match.
     -------------------------------------------------------- */
  var currentPage = window.location.pathname.split("/").pop() || "index.html";
  var allNavLinks = document.querySelectorAll(".nav-menu a");

  allNavLinks.forEach(function (link) {
    var linkPage = link.getAttribute("href");
    if (linkPage === currentPage) {
      link.classList.add("active");
    }
  });

  /* --------------------------------------------------------
     3. SIMPLE FORM HANDLING (Enquire page + Contact page)
     This is a front-end only demo: because this is a static
     website with no server/database, we can't really send the
     form anywhere. Instead we check the required fields are
     filled in and then show a friendly "thank you" message.
     -------------------------------------------------------- */
  var forms = document.querySelectorAll("form[data-demo-form]");

  forms.forEach(function (form) {
    form.addEventListener("submit", function (event) {
      // stop the browser from trying to send the form to a server
      event.preventDefault();

      // find the success message box that belongs to this form
      var successBox = form.parentElement.querySelector(".form-success");

      // very simple check: make sure the browser's built-in
      // validation (the "required" attribute in the HTML) passes
      if (form.checkValidity()) {
        if (successBox) {
          successBox.classList.add("is-visible");
        }
        form.reset(); // clears all the input fields
      } else {
        // if something required is missing, let the browser show
        // its normal validation messages
        form.reportValidity();
      }
    });
  });
});
